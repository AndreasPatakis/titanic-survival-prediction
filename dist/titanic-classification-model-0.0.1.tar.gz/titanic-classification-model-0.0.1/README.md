# titanic-survival-prediction
A classifier that predicts whether you will survive the titanic sinking, coded as for deployment in a production enviroment
